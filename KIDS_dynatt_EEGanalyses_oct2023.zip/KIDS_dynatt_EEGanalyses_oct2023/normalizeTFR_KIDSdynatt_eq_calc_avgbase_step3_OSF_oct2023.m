% RLG jan 2021 OSF. VP oct 2023.
% Perform baseline correction (power) relative change  from avg power.
% step 3 of 3

clear all; clc

%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

%% define conditions 
bin{1}='Pa1';
bin{2}='Pa2';
% load file  containing baselines for each subject in each frequency band
% (separate for each channels) - baseline is (evoked) power during average
% of all conditions (all bins)

%% execute normalization to the average baseline 
load KIDS_dynatt_eq_TFR_avg_base_evo.mat; % load .mat file from step2

for m=1:length(S) %for each subject
    suj=cat(2,'vkc_',S{m}); 
    
    for b=1:length(bin) %for each condition %

        filename = cat(2,suj,'_dynatt_',bin{b},'_eq_tfr_evo.mat')
        load(filename)

        TFdata=TFRwave_evo.powspctrm;
        baseline= avgbase_sepch{m};

        for fr=1:size(TFdata,2) % loop frequencies
            for ch=1:size(TFdata,1) % loop channels
                TFdata(ch,fr,:) = ((TFdata(ch,fr,:) - baseline(ch,fr)) / baseline(ch,fr)); % compute relative change
            end
        end
        
        TFRwave_evo.powspctrm=TFdata; %(replace old powerspectrum with new baseline corrected power)
       
        outfile = cat(2, suj,'_dynatt_',bin{b},'_eq_tfr_avblc_evo.mat');
        save(outfile,'TFRwave_evo');
        
        clear TFdata TFRwave_evo baseline outfile
    end

end

clear avgbase_sepch





