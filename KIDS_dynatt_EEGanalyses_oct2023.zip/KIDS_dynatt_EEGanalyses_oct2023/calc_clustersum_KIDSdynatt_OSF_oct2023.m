% KIDS dynatt ERP data
% RLG Jan 2021 OSF
% edited by VP Oct 2023 OSF
% for each individual subject's ERPs
% take difference between the data points in the two contrasting conditions
% for the ERP clustersums, we always computed this in the direction of Accent1 minus Accent2
% only at times and channels included in the (group-defined) cluster.

clear all; clc

%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

% load stat file w/ significant cluster
load KIDS_dynatt_eq_clustering_ERP_stat.mat

% There are 5 clusters smaller than alpha (0.05)
% Positive cluster: 1, pvalue: 0.00019996 (*), t = 0.214 to 0.41
% Positive cluster: 2, pvalue: 0.023595 (x), t = -0.03 to 0.05
% Positive cluster: 3, pvalue: 0.031594 (x), t = 0.424 to 0.5
% Negative cluster: 1, pvalue: 0.00019996 (*), t = 0.222 to 0.462
% Negative cluster: 2, pvalue: 0.0091982 (*), t = -0.046 to 0.054

% get conditions
bin{1}= stat.cond1 %
bin{2}= stat.cond2 %

% load in difference waves for each subject
for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    
    for b= 1:length(bin)
        filename = cat(2,suj,'_dynatt_',bin{b},'_eq_ERP_lpf_blc.mat')
        load(filename)
        ERPdata{m}.(bin{b}) = data;
        
        clear filename data
    end
end

% %% get info from stat file

%% POS CLUSTER 1
% % CAREFUL, POS CLUSTER!
Big_mat_all = (stat.posclusterslabelmat == 1); %find time,channel pairs where
% %electrode belongs to significant cluster (neg cluster#1)
Big_mat = squeeze(Big_mat_all);
[x,y]=find(Big_mat==1); %find channel,time pairs of significant electrodes
%
C_onlytime = squeeze(sum(Big_mat,1)); %collapse over channels to get earliest timepoint
timeind_min = min(find(C_onlytime~=0)); % just extra info
timeind_max = max(find(C_onlytime~=0));
timelim = [stat.time(timeind_min) stat.time(timeind_max)]

tt = min(stat.time);
uu = max(stat.time);

% for each subject, get cluster sum
K = [];
difwavSum = {};

for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    J ={};
    
    for b= 1:length(bin) %start bin loop
        %trimdata = ft_selectdata(cfg,ERPdata{m}.(bin{b}),'toilim',[tt uu],'avgoverchan','no','avgovertime','no'); 
        cfg         = [];
        cfg.latency  = [tt uu];     
        trimdata    = ft_selectdata(cfg, ERPdata{m}.(bin{b}));
        sujdata_bigmat = squeeze(trimdata.avg);
        % okay now Big_mat and sujdata_bigmat are equivalent  
        % redefine sujdata_bigmat by zeroeing out values not belonging to cluster.
        sujdata_onlyclust = [];
        for ch = 1:size(Big_mat,1)
            for t = 1:size(Big_mat,2)
                %multiplying by 1 or zero
                sujdata_onlyclust(ch,t) = (sujdata_bigmat(ch,t) * Big_mat(ch,t)) ;
            end
        end       
        % sum across channels
        H = sum(sujdata_onlyclust,1);       
        % sum across timepoints
        J.(bin{b}) = sum(H);
        
        clear trimdata sujdata_bigmat sujdata_onlyclust ch t H
    end % end bin loop, should have both bins now for a given subject
    
    subjectname = suj;
    % subtract cluster sums here
    L = J.(bin{1}) - J.(bin{2}) % % Leyao's scripts had this subtracted PA2-PA1 but here we should use 1-2
    
    % use this value per subject for correlational analysis:
    difwavClustsum.(subjectname) = L;
    % also save in a number-only table with subj #
    
    K(m,1) = str2num(suj(5:end)); % because suj above are mixed strings and numbers
    K(m,2) = L; % J needs to be a difference here
    K(m,3) = J.(bin{1});
    K(m,4) = J.(bin{2});
    
   clear subjectname
end

dlmwrite('Beat2_late_positivity_posterior_clustersums.txt',K,'delimiter','\t','precision','%.2f');

clear J K L 

%% POS CLUSTER 2
% % CAREFUL, POS CLUSTER!
Big_mat_all = (stat.posclusterslabelmat == 2); %find time,channel pairs where
% %electrode belongs to significant cluster (pos cluster#2)
Big_mat = squeeze(Big_mat_all);
%
[x,y]=find(Big_mat==2); %find channel,time pairs of significant electrodes %% change to 2 becaues cluster
%
C_onlytime = squeeze(sum(Big_mat,1)); %collapse over channels to get earliest timepoint
timeind_min = min(find(C_onlytime~=0)); % just extra info
timeind_max = max(find(C_onlytime~=0));
timelim = [stat.time(timeind_min) stat.time(timeind_max)];

tt = min(stat.time)
uu = max(stat.time)

% for each subject, get cluster sum
K = [];
difwavSum = {};

for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    J ={};
    
    for b= 1:length(bin) %start bin loop
        cfg         = [];
        cfg.latency  = [tt uu];     
        trimdata    = ft_selectdata(cfg, ERPdata{m}.(bin{b}));
        sujdata_bigmat = squeeze(trimdata.avg);
        %trimdata = ft_selectdata(ERPdata{m}.(bin{b}),'toilim',[tt uu],'avgoverchan','no','avgovertime','no');        
        sujdata_bigmat = squeeze(trimdata.avg);
        % okay now Big_mat and sujdata_bigmat are equivalent  
        % redefine sujdata_bigmat by zeroeing out values not belonging to cluster.
        sujdata_onlyclust = [];
        for ch = 1:size(Big_mat,1)
            for t = 1:size(Big_mat,2)
                %multiplying by 1 or zero
                sujdata_onlyclust(ch,t) = (sujdata_bigmat(ch,t) * Big_mat(ch,t)) ;
            end
        end       
        % sum across channels
        H = sum(sujdata_onlyclust,1);       
        % sum across timepoints
        J.(bin{b}) = sum(H)
        
        clear trimdata sujdata_bigmat sujdata_onlyclust ch t H
    end % end bin loop, should have both bins now for a given subject
    
    subjectname = suj;
    % subtract cluster sums here
    L = J.(bin{1}) - J.(bin{2}) % % Leyao's scripts had this subtracted PA2-PA1 but here we should use 1-2
    
    % use this value per subject for correlational analysis:
    difwavClustsum.(subjectname) = L;
    % also save in a number-only table with subj #
    
    K(m,1) = str2num(suj(5:end)); % because suj above are mixed strings and numbers
    K(m,2) = L; % J needs to be a difference here
    K(m,3) = J.(bin{1});
    K(m,4) = J.(bin{2});
    
   clear subjectname
end

dlmwrite('Beat1_early_positivity_posterior_clustersums.txt',K,'delimiter','\t','precision','%.2f');
clear J K L 


%% POS CLUSTER 3
% % CAREFUL, POS CLUSTER!
Big_mat_all = (stat.posclusterslabelmat == 3); %find time,channel pairs where
% %electrode belongs to significant cluster (pos cluster#2)
Big_mat = squeeze(Big_mat_all);
%
[x,y]=find(Big_mat==3); %find channel,time pairs of significant electrodes %% change to 2 becaues cluster
%
C_onlytime = squeeze(sum(Big_mat,1)); %collapse over channels to get earliest timepoint
timeind_min = min(find(C_onlytime~=0)); % just extra info
timeind_max = max(find(C_onlytime~=0));
timelim = [stat.time(timeind_min) stat.time(timeind_max)];

tt = min(stat.time)
uu = max(stat.time)

% for each subject, get cluster sum
K = [];
difwavSum = {};

for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    J ={};
    
    for b= 1:length(bin) %start bin loop
        cfg         = [];
        cfg.latency  = [tt uu];     
        trimdata    = ft_selectdata(cfg, ERPdata{m}.(bin{b}));
        sujdata_bigmat = squeeze(trimdata.avg);
        %trimdata = ft_selectdata(ERPdata{m}.(bin{b}),'toilim',[tt uu],'avgoverchan','no','avgovertime','no');        
        sujdata_bigmat = squeeze(trimdata.avg);
        % okay now Big_mat and sujdata_bigmat are equivalent  
        % redefine sujdata_bigmat by zeroeing out values not belonging to cluster.
        sujdata_onlyclust = [];
        for ch = 1:size(Big_mat,1)
            for t = 1:size(Big_mat,2)
                %multiplying by 1 or zero
                sujdata_onlyclust(ch,t) = (sujdata_bigmat(ch,t) * Big_mat(ch,t)) ;
            end
        end       
        % sum across channels
        H = sum(sujdata_onlyclust,1);       
        % sum across timepoints
        J.(bin{b}) = sum(H)
        
        clear trimdata sujdata_bigmat sujdata_onlyclust ch t H
    end % end bin loop, should have both bins now for a given subject
    
    subjectname = suj;
    % subtract cluster sums here
    L = J.(bin{1}) - J.(bin{2}) % % Leyao's scripts had this subtracted PA2-PA1 but here we should use 1-2
    
    % use this value per subject for correlational analysis:
    difwavClustsum.(subjectname) = L;
    % also save in a number-only table with subj #
    
    K(m,1) = str2num(suj(5:end)); % because suj above are mixed strings and numbers
    K(m,2) = L; % J needs to be a difference here
    K(m,3) = J.(bin{1});
    K(m,4) = J.(bin{2});
    
   clear subjectname
end

dlmwrite('Beat2_late_negativity_frontal2_clustersums.txt',K,'delimiter','\t','precision','%.2f');

clear J K L 

%% NEG CLUSTER 1
% % CAREFUL, NEG CLUSTER!
Big_mat_all = (stat.negclusterslabelmat == 1); %find time,channel pairs where
% %electrode belongs to significant cluster (neg cluster#1)
Big_mat = squeeze(Big_mat_all);
%
[x,y]=find(Big_mat==1); %find channel,time pairs of significant electrodes
%
C_onlytime = squeeze(sum(Big_mat,1)); %collapse over channels to get earliest timepoint
timeind_min = min(find(C_onlytime~=0)); % just extra info
timeind_max = max(find(C_onlytime~=0));
timelim = [stat.time(timeind_min) stat.time(timeind_max)];

tt = min(stat.time)
uu = max(stat.time)

% for each subject, get cluster sum
K = [];
difwavSum = {};

for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    J ={};
    
    for b= 1:length(bin) %start bin loop
        cfg         = [];
        cfg.latency  = [tt uu];     
        trimdata    = ft_selectdata(cfg, ERPdata{m}.(bin{b}));

        % trimdata = ft_selectdata(ERPdata{m}.(bin{b}),'toilim',[tt uu],'avgoverchan','no','avgovertime','no');        
        sujdata_bigmat = squeeze(trimdata.avg);
        % okay now Big_mat and sujdata_bigmat are equivalent  
        % redefine sujdata_bigmat by zeroeing out values not belonging to cluster.
        sujdata_onlyclust = [];
        for ch = 1:size(Big_mat,1)
            for t = 1:size(Big_mat,2)
                %multiplying by 1 or zero
                sujdata_onlyclust(ch,t) = (sujdata_bigmat(ch,t) * Big_mat(ch,t)) ;
            end
        end       
        % sum across channels
        H = sum(sujdata_onlyclust,1);       
        % sum across timepoints
        J.(bin{b}) = sum(H);
        
        clear trimdata sujdata_bigmat sujdata_onlyclust ch t H
    end % end bin loop, should have both bins now for a given subject
    
    subjectname = suj;
    % subtract cluster sums here
    L = J.(bin{1}) - J.(bin{2}); % % Leyao's scripts had this subtracted PA2-PA1 but here we should use 1-2
    
    % use this value per subject for correlational analysis:
    difwavClustsum.(subjectname) = L;
    % also save in a number-only table with subj #
    
    K(m,1) = str2num(suj(5:end)); % because suj above are mixed strings and numbers
    K(m,2) = L; % J needs to be a difference here
    K(m,3) = J.(bin{1});
    K(m,4) = J.(bin{2});
    
end

dlmwrite('Beat2_late_negativity_frontal1_clustersums.txt',K,'delimiter','\t','precision','%.2f');

clear J K L 

%% NEG CLUSTER 2
% % CAREFUL, NEG CLUSTER!
Big_mat_all = (stat.negclusterslabelmat == 2); %find time,channel pairs where
% %electrode belongs to significant cluster (neg cluster#2)
Big_mat = squeeze(Big_mat_all);
%
[x,y]=find(Big_mat==2); %find channel,time pairs of significant electrodes
%
C_onlytime = squeeze(sum(Big_mat,1)); %collapse over channels to get earliest timepoint
timeind_min = min(find(C_onlytime~=0)); % just extra info
timeind_max = max(find(C_onlytime~=0));
timelim = [stat.time(timeind_min) stat.time(timeind_max)];

tt = min(stat.time)
uu = max(stat.time)

% for each subject, get cluster sum
K = [];
difwavSum = {};

for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    J ={};
    
    for b= 1:length(bin) %start bin loop
        %trimdata = ft_selectdata(ERPdata{m}.(bin{b}),'toilim',[tt uu],'avgoverchan','no','avgovertime','no'); 
         cfg         = [];
        cfg.latency  = [tt uu];     
        trimdata    = ft_selectdata(cfg, ERPdata{m}.(bin{b}));
        sujdata_bigmat = squeeze(trimdata.avg);
        % okay now Big_mat and sujdata_bigmat are equivalent  
        % redefine sujdata_bigmat by zeroeing out values not belonging to cluster.
        sujdata_onlyclust = [];
        for ch = 1:size(Big_mat,1)
            for t = 1:size(Big_mat,2)
                %multiplying by 1 or zero
                sujdata_onlyclust(ch,t) = (sujdata_bigmat(ch,t) * Big_mat(ch,t)) ;
            end
        end       
        % sum across channels
        H = sum(sujdata_onlyclust,1);       
        % sum across timepoints
        J.(bin{b}) = sum(H);
        
        clear trimdata sujdata_bigmat sujdata_onlyclust ch t H
    end % end bin loop, should have both bins now for a given subject
    
    subjectname = suj;
    % subtract cluster sums here
    L = J.(bin{1}) - J.(bin{2}) % % Leyao's scripts had this subtracted PA2-PA1 but here we should use 1-2
    
    % use this value per subject for correlational analysis:
    difwavClustsum.(subjectname) = L;
    % also save in a number-only table with subj #
    
    K(m,1) = str2num(suj(5:end)); % because suj above are mixed strings and numbers
    K(m,2) = L; % J needs to be a difference here
    K(m,3) = J.(bin{1});
    K(m,4) = J.(bin{2});
    
end

dlmwrite('Beat1_early_negativity_frontal_clustersums.txt',K,'delimiter','\t','precision','%.2f');

clear J K L 


