% cluster-based permutation test ERPs
% RLG jan. 2021 for OSF. VP oct. 2023.

clear all; clc
restoredefaultpath
addpath /Users/reyna/Documents/fieldtrip-20190419
   ft_defaults
    global ft_default
ft_default.spmversion = 'spm12'


ft_defaults

%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};


%% define conditions. 
bin{1}='Pa1';
bin{2}='Pa2';

% load files for all subjects and conditions into one structure
for b=1:length(bin)
    
    filename = cat(2,'KIDSdynatt_eq_ERP_blclpf_', bin{b}, '_allSubj.mat'); %change by hand
    load(filename);
    
    data{b} = ERP_AllSubj;
    clear ERP_AllSubj
    
end

% read in list of channels that we want to test (this file excludes eye channels)
cfg = [];

elec= ft_read_sens('GSN128_positions_4clustering.sfp')

load EGI_layout129.lay.mat
cfg = [];
cfg.spmversion = 'spm12'; %fit the version of computer
cfg.layout           = EGI_layout129;
cfg.method           = 'triangulation'; %this method is better than distance
neighbours = ft_prepare_neighbours(cfg,EGI_layout129);

nsubj=length(S);

%% perform the statistical test using randomization and a clustering approach
% ERP
cfg = [];
cfg.channel          = elec.label; %take all electrodes in new montage
cfg.neighbours       = neighbours;
%cfg.neighbourdist    = 15; %max distance for neighbor channels to be included in cluster
cfg.elec             = elec;
cfg.statistic        = 'depsamplesT'; %because within-subject design, but if using more than two conditions, must use F-statistic
cfg.minnbchan        = 2; % minimum number of neighbor channels for a cluster % changed on July 31
cfg.clusteralpha     = 0.05; 
cfg.alpha            = 0.025; % alpha for the dependent t-tests. Must be 0.025 if using 2-tailed test.
cfg.clustertail      = 0; %has to be 1 if Ftest
cfg.tail             = 0; %has to be 1 if Ftest
cfg.numrandomization = 5000; % number of permutations %% RLG changed to 5000 permutations 19-April-2020

cfg.latency          = [-0.100 0.500]; % time window in seconds
cfg.avgovertime      = 'no'; 
cfg.avgoverchan      = 'no';

cfg.correctm         = 'cluster';
cfg.method           = 'montecarlo';
cfg.feedback         = 'gui';

designsubj  = 1:1:nsubj;
designcond1 = repmat(1,1,nsubj);
designcond2 = repmat(2,1,nsubj);

design      = [designsubj designsubj; designcond1 designcond2];
cfg.design  = design;
cfg.uvar = 1;   % "subject" is unit of observation
cfg.ivar = 2;   % the row of the design matrix containing the ind.variable

 global ft_default;
 ft_default.spmversion = 'spm12';
 ft_defaults; % this loads the rest of the defaults
 
 
[stat]    = ft_timelockstatistics(cfg, data{1}, data{2}); 
stat.cond1 = bin{1}; 
stat.cond2 = bin{2};
save KIDS_dynatt_eq_clustering_ERP_stat.mat stat;
clear stat

% note that the pvalues will be slightly different each time this runs, due
% to the random pulls in the bootstrapping, but the cluster latencies do
% not change.

% Below are the results reported in the paper from when we ran it:
% There are 5 clusters smaller than alpha (0.05)
% Positive cluster: 1, pvalue: 0.00019996 (*), t = 0.214 to 0.41
% Positive cluster: 2, pvalue: 0.023595 (x), t = -0.03 to 0.05
% Positive cluster: 3, pvalue: 0.031594 (x), t = 0.424 to 0.5
% Negative cluster: 1, pvalue: 0.00019996 (*), t = 0.222 to 0.462
% Negative cluster: 2, pvalue: 0.0091982 (*), t = -0.046 to 0.054
