% KIDS EEG Grammar paper - Persici et al. (2023)
% RLG 14jan 2021 for OSF, edited by VP Oct 17 2023.
clear all; clc
% compute ERPs and wavelet-based time-frequency representations. 
% the output of this script are available in OSF archive.
tic %calculate time it takes for script to run, "toc" on final line

restoredefaultpath
addpath /Users/reyna/Documents/fieldtrip-20190419
   ft_defaults
    global ft_default
ft_default.spmversion = 'spm12';

%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

%% define conditions %
bin{1}='Pa1'; % Accent1
bin{2}='Pa2'; % Accent2

load trialguide_vkc.mat % this says how many trials to take for each participant in this dataset -

%% calculate wavelet power

for m=1:length(S) %for each subject
    
    suj=cat(2,'vkc_',S{m}); % 
    
    for b=1:length(bin) %for each condition specified above
        filename= cat(2,suj,'_',bin{b},'.mat')

        load(filename)
        SampRate = data.fsample %finds the sampling rate of this dataset and finds timestep for analysis
        
        cfg = [];
        cfg.dftfilter     = 'yes'; % line noise removal using discrete fourier transform (default = 'no')
        cfg.dftfreq  = [60 120 180]; %line noise frequencies in Hz for DFT filter
        cfg.continuous   = 'no'; % added this on 6-28-20.    
        trialstop = trialguide_vkc(m,b+1); % use m and b index to get the right cell in trialguide
        cfg.trials = 1:trialstop; % added this on 6-28-20
        data_fil = ft_preprocessing(cfg,data);  

        % calculate ERP
        cfg = [];
        cfg.removemean  = 'no';
        data_ERP = ft_timelockanalysis(cfg, data_fil); % compute ERP to be saved, and used for evoked
        
        outfile_4evo = cat(2,suj,'_dynatt_',bin{b},'_ERP_eq.mat')
        save (outfile_4evo,'data_ERP');
        
        clear data data_fil
        %% then run wavelet on ERP data
        
        timestep = 1/SampRate;
        % you can increase computation speed by increasing the numerator of this
        % equation, but that will affect the temporal resolution amd your graphical
        % output will be less smooth
        
        cfg = [];

        cfg.method  = 'wavelet';
        cfg.width   =  6; % 6 cycles %this can be a vector if you want to do classical-Q
        cfg.output  = 'pow';
        cfg.foi     = 12:1:50; %frequencies of interest - step of 1 Hz for better resolution
        cfg.toi     = -0.200:timestep:0.800;    %time of interest - time in seconds, 2ms; use wide window for visualization purposes
        cfg.keeptrials = 'no'; %return individual trials or average (default = 'no') (default = 'no')
        
        TFRwave_evo = ft_freqanalysis(cfg, data_ERP);
        
        outfile= cat(2,suj,'_dynatt_',bin{b},'_eq_tfr_evo.mat') % changed output to convey eq
        save(outfile,'TFRwave_evo');
        clear data_ERP  outfile TFRwave_evo
    end
    clear filename
end

toc

