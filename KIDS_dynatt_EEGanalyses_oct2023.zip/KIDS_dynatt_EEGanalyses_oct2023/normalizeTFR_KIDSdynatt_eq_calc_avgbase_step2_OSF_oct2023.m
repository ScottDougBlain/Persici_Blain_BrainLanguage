% RLG jan 2021 OSF. VP oct 2023.
% TFR normalization step 2 of 3. 
% takes  average power across conditions for each subject and compiles it
% into a matrix that will be a baseline. It yields a separate mean for each 
% frequency and channel.    Evoked TFRs.
% step 2 of 3

clc; clear all
%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

%you don't need to define conditions in this one because you took the
%average across conditions
%in the last script
%% load in average data and save

for m=1:length(S) %for each subject
    suj=cat(2,'vkc_',S{m});

    filename = cat(2, suj,'_dynatt_avgbins_eq_tfr_evo.mat');
    load(filename)

    for j=1:size(TFRwave_evo.powspctrm,2) %loop frequencies
        for k=1:size(TFRwave_evo.powspctrm,1) %loop channels
            %calculate mean power per frequency per channel across time
            avgbase_sepch{m}(k,j)       = nanmean(TFRwave_evo.powspctrm(k,j,:)); 

        end
    end
    clear filename TFRwave_evo
end

save KIDS_dynatt_eq_TFR_avg_base_evo.mat avgbase_sepch
clear avgbase_sepch

