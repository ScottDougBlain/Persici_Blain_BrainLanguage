% This script computes average TFRs across conditions to use as baseline
% RLG jan 2021 for OSF. VP oct 2023.
% This is Step 1 of 3 steps

clc; clear all

%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

%% define conditions 

bin{1}='Pa1';
bin{2}='Pa2';

%% calculate average power for targets
for m=1:length(S) %for each subject
    suj=cat(2,'vkc_',S{m}); %
    
    for b=1:length(bin) %for each condition specified above
        filename= cat(2,suj,'_dynatt_',bin{b},'_eq_tfr_evo.mat')
        data.(bin{b})=load(filename);
        clear filename
    end
    
    cfg = [];
    cfg.keepindividual = 'no'; %now compute average spectra across conditions for each S;
    % if you have a different # of conditions, the line below would need to be adjusted
    TFRwave_evo = ft_freqgrandaverage(cfg, data.(bin{1}).TFRwave_evo, data.(bin{2}).TFRwave_evo);
    outfile = cat(2, suj,'_dynatt_avgbins_eq_tfr_evo.mat');
    save(outfile,'TFRwave_evo');
    clear TFRwave_evo data outfile
end


