%% RLG jan 2021 OSF. VP oct 2023.
% run cluster-based permutations on Evoked Beta and Gamma 
clear all; clc 

restoredefaultpath
addpath /Users/reyna/Documents/fieldtrip-20190419
ft_defaults
    global ft_default
ft_default.spmversion = 'spm12'


tic
%% define subjects 

S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

%% define conditions 
bin{1}='Pa1'; % Accent1
bin{2}='Pa2'; % Accent2

% these files contain all subjects in one structure
for b=1:length(bin)
    
    filename = cat(2,'KIDSdynatt_eq_avblc_evo_', bin{b}, '_allSubj.mat')
    load(filename);
    data{b}=TF_Subj_evo;
    clear TF_Subj_evo
    
end

%Read in the electrode locations for the my montage

elec= ft_read_sens('GSN128_positions_4clustering.sfp');

load EGI_layout129.lay.mat
cfg = [];
cfg.spmversion = 'spm12'; %fit the version of computer
cfg.layout           = EGI_layout129;
cfg.method           = 'triangulation'; %this method is better than distance
neighbours = ft_prepare_neighbours(cfg,EGI_layout129);


%% perform the statistical test using randomization and a clustering approach
% beta
cfg = [];
cfg.channel          = elec.label; %
nsubj=length(S);
cfg.neighbours       = neighbours;
cfg.elec             = elec;
cfg.statistic        = 'depsamplesT'; %because within-subject design, but if using more than two conditions, must use F-statistic
cfg.minnbchan        = 2;
cfg.clusteralpha     = 0.05;
cfg.alpha            = 0.025;
cfg.clustertail      = 0; 
cfg.tail             = 0; 
cfg.numrandomization = 5000; %

cfg.latency          = [-0.100 0.500]; % in seconds
cfg.frequency        = [13 23]; %beta
cfg.avgovertime      = 'no'; 
cfg.avgoverfreq      = 'yes';
cfg.avgoverchan      = 'no';

cfg.correctm         = 'cluster';
cfg.method           = 'montecarlo';
cfg.feedback         = 'gui';

designsubj  = 1:1:nsubj;
designcond1 = ones(1,nsubj);
designcond2 = repmat(2,1,nsubj);

design      = [designsubj designsubj; designcond1 designcond2];
cfg.design  = design;
cfg.uvar = 1;   % "subject" is unit of observation
cfg.ivar = 2;   %2:3;   % "syllables and regularity are " the independent variables
%% 

[stat]    = ft_freqstatistics(cfg, data{1}, data{2}); %
stat.cond1 = bin{1};
stat.cond2 = bin{2};
outfile     =  'KIDS_dynatt_eq_clustering_evo_beta_OSF_stat.mat';

save(outfile, 'stat');
clear outfile stat


%% perform the statistical test using randomization and a clustering approach
% GAMMA
cfg = [];
cfg.channel          = elec.label; %
nsubj=length(S);
cfg.neighbours       = neighbours;
cfg.elec             = elec;
cfg.statistic        = 'depsamplesT'; %because within-subject design, but if using more than two conditions, must use F-statistic
cfg.minnbchan        = 2;
cfg.clusteralpha     = 0.05;
cfg.alpha            = 0.025;
cfg.clustertail      = 0; 
cfg.tail             = 0; 
cfg.numrandomization = 5000; % number of permutations 

cfg.latency          = [-0.100 0.500]; % in seconds
cfg.frequency        = [24 50]; %gamma
cfg.avgovertime      = 'no'; 
cfg.avgoverfreq      = 'yes';
cfg.avgoverchan      = 'no';

cfg.correctm         = 'cluster';
cfg.method           = 'montecarlo';
cfg.feedback         = 'gui';

designsubj  = 1:1:nsubj;
designcond1 = ones(1,nsubj);
designcond2 = repmat(2,1,nsubj);


%design      = [designsubj designsubj designsubj designsubj; designcond1 designcond2 designcond3 designcond4; designcond5 designcond6 designcond7 designcond8];
design      = [designsubj designsubj; designcond1 designcond2];
cfg.design  = design;
cfg.uvar = 1;   % "subject" is unit of observation
cfg.ivar = 2;   % experimental conditions Accent1 and Accent2 are the independent variables
%% 

[stat]    = ft_freqstatistics(cfg, data{1}, data{2}); %
stat.cond1 = bin{1};
stat.cond2 = bin{2};

outfile     =  'KIDS_dynatt_eq_clustering_evo_gamma_OSF_stat.mat';
save(outfile, 'stat');
clear outfile stat

toc 

%% CLUSTERING RESULTS
% note that the pvalues will be slightly different each time this runs, due
% to the random pulls in the bootstrapping, but the cluster latencies do
% not change.
% Below are the results reported in the paper from when we ran it:

% Evoked Beta
% There are 2 clusters smaller than alpha (0.05)
% Positive cluster: 1, pvalue: 0.00019996 (*), t = -0.092 to 0.146
% Negative cluster: 1, pvalue: 0.0059988 (*), t = 0.214 to 0.352

% Evoked Gamma

% % EQ TRIAL RESULTS new neighbor parameter
% There are 2 clusters smaller than alpha (0.05)
% Positive cluster: 1, pvalue: 0.032993 (x), t = 0.05 to 0.12
% Negative cluster: 1, pvalue: 0.027594 (x), t = 0.238 to 0.306

