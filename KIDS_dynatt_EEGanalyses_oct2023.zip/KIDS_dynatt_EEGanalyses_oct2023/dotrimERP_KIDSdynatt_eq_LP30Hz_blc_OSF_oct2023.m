% Individual differences in neural markers of beat processing relate to
% spoken grammar skills in six-year-old children -  Persici et al. (2023)
% RLG Jan. 2021. VP Oct. 2023.
% low-pass filter and baseline correct ERPs
clear all; clc

%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

%% define conditions %
bin{1}='Pa1';
bin{2}='Pa2';

for m=1:length(S) %for each subject
    suj=cat(2,'vkc_',S{m}); 
    
    for b=1:length(bin) %for each condition specified above
        filename= cat(2,suj,'_dynatt_',bin{b},'_ERP_eq.mat') % these contain ind. subj. averages
        load(filename);
        
        %Low-pass filter trial data
        cfg = [];
        cfg.lpfilter = 'yes';
        cfg.lpfreq = 30;
        data_fil = ft_preprocessing(cfg,data_ERP);
        
        cfg= [];
        cfg.baseline= [-0.100 0]; % baseline correction

        data_blc = ft_timelockbaseline(cfg,data_fil);
        clear data
        
        % trim off excess data and narrows to the window in which we want
        % to see the ERP
        cfg= [];
        cfg.latency = [-0.100 0.700]; 
        data = ft_selectdata(cfg,data_blc); % 

        outfile= cat(2,suj,'_dynatt_',bin{b},'_eq_ERP_lpf_blc.mat')
        save(outfile,'data');
        clear outfile data data_ERP data_fil data_blc filename outfile
        
    end
end

