%% jan 2021 RLG for OSF. VP Oct 2023.
% for each individual subject:
% take difference between the data points in the two contrasting conditions
% only at times and frequencies included in the (group-defined) cluster.
% creates a variable to be used in brain-behavior analyses

% EVOKED GAMMA CLUSTER
clear all; clc

%load stat file (output from clustering)
load KIDS_dynatt_eq_clustering_evo_gamma_OSF_stat.mat

%% define subjects
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};
%
bin{1}= stat.cond1 % Accent1
bin{2}= stat.cond2 % Accent2
% note that we compute Accent1-Accent2 here, but later we reverse direction
% for negative clusters on Beat2 (see R scripts used for brain-behavior
% correlations)

% load in individual data for each subject
for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    for b= 1:length(bin)
        filename = cat(2, suj,'_dynatt_',bin{b},'_eq_tfr_avblc_evo.mat');
        
        load(filename)
        data{m}.(bin{b}) = TFRwave_evo;
        
        clear filename TFRwave_evo
    end
end

% uses info from stat file
%% GAMMA positive cluster
% start with
Big_mat_all = (stat.posclusterslabelmat == 1); %find time,channel pairs where
%electrode belongs to significant cluster POS cluster#1)
Big_mat = squeeze(Big_mat_all);

[x,y]=find(Big_mat==1); %find channel,time pairs of significant electrodes

C_onlytime = squeeze(sum(Big_mat,1)); %collapse over channels to get earliest timepoint
timeind_min = min(find(C_onlytime~=0)); % just extra info
timeind_max = max(find(C_onlytime~=0));
timelim = [stat.time(timeind_min) stat.time(timeind_max)] % what is going on here?

freqband = stat.cfg.frequency % frequency band

tt = min(stat.time)
uu = max(stat.time)


%% for each subject, get cluster sum

difwavClustsum = {};

for m=1:length(S) % start subject loop
    suj=cat(2,'vkc_',S{m});
    
    J ={};
    
    for b= 1:length(bin) %start bin loop
        % take just timepoints and frequencies in the sig. cluster,but all channels
        % for now, or better to take stat.time to have equivalent matrices
        % alternative: data = ft_selectdata(TFRwave_evo,'foilim',freqband,'toilim',timelim)
        % problem is with ft_selectdata here.
        %         trimdata = ft_selectdata(data{m}.(bin{b}),'avgoverfreq','yes','foilim',freqband,'toilim',[tt uu]);
        %         % okay now Big_mat and sujdata_bigmat are equivalent
        cfg         = [];
        cfg.latency  = [tt uu];
        cfg.avgoverfreq = 'yes';
        cfg.frequency   = freqband;
        trimdata    = ft_selectdata(cfg, data{m}.(bin{b}));
        sujdata_bigmat = squeeze(trimdata.powspctrm);
        
        % redefine sujdata_bigmat by zeroeing out values not belonging to cluster.
        sujdata_onlyclust = [];
        
        for ch = 1:size(Big_mat,1)
            for t = 1:size(Big_mat,2)
                %multiplying by 1 or zero
                sujdata_onlyclust(ch,t) = (sujdata_bigmat(ch,t) * Big_mat(ch,t)) ;
                
            end
        end
        
        % sum across channels
        H = sum(sujdata_onlyclust,1);
        
        % sum across timepoints
        J.(bin{b}) = sum(H);
        
        clear trimdata sujdata_bigmat sujdata_onlyclust ch t H
    end % end bin loop, should have both bins now for a given subject
    
    subjectname = suj;
    % subtract cluster sums here
    L = J.(bin{1}) - J.(bin{2});
    
    % use this value per subject for corr analysis:
    difwavClustsum.(subjectname) = L;
    % also save in a number-only table with subj #
    
    K(m,1) =  str2num(suj(5:end)); % because suj above are mixed strings and numbers
    K(m,2) = L; % J needs to be a difference here
    K(m,3) = J.(bin{1});
    K(m,4) = J.(bin{2});
    
    
    clear L J subjectname
end

dlmwrite('EEG_gamma_Beat1effect_clustersums.txt',K,'delimiter','\t','precision','%.2f');

output = rows2vars(struct2table(difwavClustsum));
writetable(output,'EEG_gamma_Beat1effect.txt','Delimiter','\t')

clearvars -except S data stat bin  % clears out all the variables used in this clustersum, leaves only the variables needed for the next cluster sum


%% GAMMA negative cluster
% start with
Big_mat_all = (stat.negclusterslabelmat == 1); %find time,channel pairs where
%electrode belongs to significant cluster POS cluster#1)
Big_mat = squeeze(Big_mat_all);

[x,y]=find(Big_mat==1); %find channel,time pairs of significant electrodes

C_onlytime = squeeze(sum(Big_mat,1)); %collapse over channels to get earliest timepoint
timeind_min = min(find(C_onlytime~=0)); % just extra info
timeind_max = max(find(C_onlytime~=0));
timelim = [stat.time(timeind_min) stat.time(timeind_max)] % 

freqband = stat.cfg.frequency % frequency band

tt = min(stat.time)
uu = max(stat.time)

% 
%% for each subject, get cluster sum

difwavClustsum = {};

for m=1:length(S) % start subject loop
    suj=cat(2,'vkc_',S{m});
    
    J ={};
    
    for b= 1:length(bin) %start bin loop
        cfg         = [];
        cfg.latency  = [tt uu];
        cfg.avgoverfreq = 'yes';
        cfg.frequency   = freqband;
        trimdata    = ft_selectdata(cfg, data{m}.(bin{b}));
        
        sujdata_bigmat = squeeze(trimdata.powspctrm);
        
        for ch = 1:size(Big_mat,1)
            for t = 1:size(Big_mat,2)
                %multiplying by 1 or zero
                sujdata_onlyclust(ch,t) = (sujdata_bigmat(ch,t) * Big_mat(ch,t)) ;
                
            end
        end
        
        % sum across channels
        H = sum(sujdata_onlyclust,1);
        
        % sum across timepoints
        J.(bin{b}) = sum(H);
        
        clear trimdata sujdata_bigmat sujdata_onlyclust ch t H
    end % end bin loop, should have both bins now for a given subject
    
    subjectname = suj;
    % subtract cluster sums here
    L = J.(bin{1}) - J.(bin{2});
    
    % use this value per subject for corr analysis:
    difwavClustsum.(subjectname) = L;
    % also save in a number-only table with subj #
    
    K(m,1) =  str2num(suj(5:end)); % because suj above are mixed strings and numbers
    K(m,2) = L; %
    K(m,3) = J.(bin{1});
    K(m,4) = J.(bin{2});
    
    clear L J subjectname
end

dlmwrite('EEG_gamma_Beat2effect_clustersums.txt',K,'delimiter','\t','precision','%.2f');

output = rows2vars(struct2table(difwavClustsum));
writetable(output,'EEG_gamma_Beat2effect.txt','Delimiter','\t')

