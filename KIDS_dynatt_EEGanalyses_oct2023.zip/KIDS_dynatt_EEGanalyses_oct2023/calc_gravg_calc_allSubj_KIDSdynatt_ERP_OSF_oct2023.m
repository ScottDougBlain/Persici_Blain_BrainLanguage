% Create grand average ERPs plus another file with individual ERPs compiled
% for all participants
% RLG jan. 2021 for OSF. VP oct. 2023.
clear all; clc

restoredefaultpath
addpath /Users/reyna/Documents/fieldtrip-20190419
ft_defaults
global ft_default
ft_default.spmversion = 'spm12';

%% define subjects
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};
%% define conditions

bin{1}='Pa1';
bin{2}='Pa2';

%generate file name to read
for m=1:length(S)
    suj=cat(2,'vkc_',S{m});
    
    for b=1:length(bin)
        file_cond.(bin{b}){m}= cat(2,suj,'_dynatt_',bin{b},'_eq_ERP_lpf_blc.mat') % read in low-pass filtered, baseline-corrected files.
    end
    
end

%nsubj = length(S);

for m=1:length(S)
    
    for b=1:length(bin)
        
        data =load(file_cond.(bin{b}){m}); %load the file for each condition and each subject, put in one structure
        data_ERP = data.data;% take only what we need
        ERP_all.(bin{b}){m} = data_ERP;
        clear data data_ERP
    end
end


load EGI_layout129.lay.mat

%% compute grand Average (average across participants)
%
cfg.keepindividual = 'no'; % we want a grand average, so don't save individual subjects
cfg.layout       = EGI_layout129;  %layout file
cfg.latency     = 'all';

for b=1:length(bin)
    
    gravg.(bin{b})=   ft_timelockgrandaverage(cfg,ERP_all.(bin{b}){:});
    outfile     =  cat(2, 'KIDSdynatt_eq_ERP_blclpf_', bin{b}, '_gravg.mat')
    ERP_Combinedavg =  gravg.(bin{b});
    save(outfile, 'ERP_Combinedavg');
    
    clear outfile ERP_Combinedavg
    
end

clear gravg

%% compute all subjects file (this will be used for clustering stat analyses)
cfg = [];
cfg.keepindividual = 'yes'; %put yes to save averages for each subject in file
cfg.layout       = EGI_layout129;  %layout file
cfg.latency     = 'all';

for b=1:length(bin)
    
    allSubj.(bin{b})=   ft_timelockgrandaverage(cfg,ERP_all.(bin{b}){:});
    outfile     =  cat(2,'KIDSdynatt_eq_ERP_blclpf_', bin{b}, '_allSubj.mat')
    ERP_AllSubj =  allSubj.(bin{b});
    save(outfile, 'ERP_AllSubj');
    
    clear outfile ERP_AllSubj
    
end

clear allSubj

