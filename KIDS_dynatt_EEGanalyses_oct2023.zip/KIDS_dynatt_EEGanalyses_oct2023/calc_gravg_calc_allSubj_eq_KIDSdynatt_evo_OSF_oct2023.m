% RLG jan 2021 for OSF. VP oct 2023.
% load in baseline-corrected TFR EVOKED 
% two outputs: 1 grand average
% and one that keeps individual subjects, for the cluster analysis
clear all; clc 
%% define subjects 
S = {'650', '651', '652', '654', '655', '656', '657', '658', '661', '662', '663', '666', '668', '669', '671', '672', '673', '674', '675' '676', '679', '684', '687', '689', '699'};

%% define conditions 
bin{1}='Pa1';
bin{2}='Pa2';

%%

for m=1:length(S)
    suj=cat(2,'vkc_',S{m});

    for b=1:length(bin)
        file_cond.(bin{b}){m}= cat(2, suj,'_dynatt_',bin{b},'_eq_tfr_avblc_evo.mat'); % load normalized TFR files 
    end
    
end

%nsubj = length(S);

for m=1:length(S)
    
    for b=1:length(bin)
        
        data.(bin{b}){m}=load(file_cond.(bin{b}){m}); %load the file for each condition and each subject, put in one structure
        TFdata.(bin{b}){m} = data.(bin{b}){m}.TFRwave_evo % take only what we need (TFdata)
        
    end
    clear data
end
clear data

load EGI_layout129.lay.mat % 

 %% compute grand average (average of all subjects)
cfg = [];
cfg.keepindividual = 'no'; % grand average! 
cfg.layout       = EGI_layout129; 

% this collects all identical time/frequency/channel samples over all
% subjects into a single data structure     
 
 for b=1:length(bin)
   
    gravg.(bin{b})=   ft_freqgrandaverage(cfg,TFdata.(bin{b}){:});
    outfile     =  cat(2,'KIDSdynatt_eq_avblc_evo_', bin{b}, '_gravg.mat')
    TF_gravg_evo =  gravg.(bin{b});
    save(outfile, 'TF_gravg_evo');
    
    clear outfile TF_gravg_evo
    
 end

%% compute "all subjects" file (this will be used for clustering stat analyses)

cfg = [];
cfg.keepindividual = 'yes'; %
cfg.layout       = EGI_layout129;
 
 for b=1:length(bin)
   
    allSubj.(bin{b})=   ft_freqgrandaverage(cfg,TFdata.(bin{b}){:});
    outfile     =  cat(2,'KIDSdynatt_eq_avblc_evo_', bin{b}, '_allSubj.mat')
    TF_Subj_evo =  allSubj.(bin{b});
    save(outfile, 'TF_Subj_evo');
    
    clear outfile TF_Subj_evo
    
 end



