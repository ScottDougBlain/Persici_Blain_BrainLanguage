% Analysis guide for Individual differences in neural markers of beat
% processing relate to spoken grammar skills in six-year-old children (Persici, et al.,2023) 
% for OSF Oct 2023
% we used the April 19, 2019 version of the fieldtrip toolbox.
% 
%%
% place all scripts in same folder as the data
restoredefaultpath
addpath /Users/reyna/Documents/fieldtrip-20190419
ft_defaults
global ft_default
ft_default.spmversion = 'spm12';

%experimental conditions:
%Accent1 is 'Pa1';
%Accent2 is 'Pa2';

%% ERP analyses
% compute ERP and TFR wavelets on the N=25 TD KIDSdynatt trial data
dowaveletandERP_KIDSdynatt_tf_evoandERP_OSF % output from this step is included in OSF archive

% Low-pass filter and baseline correct ERPs
dotrimERP_KIDSdynatt_eq_LP30Hz_blc_OSF

% compute grand averages and prepare for cluster-based permutation
calc_gravg_calc_allSubj_KIDSdynatt_ERP_OSF

% cluster-based permutation statistical tests
cluster_KIDSdynatt_ERP_OSF

% compute "clustersums" (individual scores based on parameters of group-level clusters)
calc_clustersum_KIDSdynatt_OSF

%% TFR analyses
% Normalize to the average of all conditions
normalizeTFR_KIDSdynatt_eq_calc_avgbase_step1_OSF

normalizeTFR_KIDSdynatt_eq_calc_avgbase_step2_OSF

normalizeTFR_KIDSdynatt_eq_calc_avgbase_step3_OSF

% compute grand averages and prepare for cluster-based permutations
calc_gravg_calc_allSubj_eq_KIDSdynatt_evo_OSF

% cluster-based permutation statistical tests
cluster_KIDSdynatt_eq_evoBetaGamma_OSF

% compute "clustersums" (individual scores based on parameters of group-level clusters)
calc_clustersum_KIDSdynatt_EvoBeta_OSF
calc_clustersum_KIDSdynatt_EvoGamma_OSF

% Remaining analyses were performed in R; see R scripts and R
% dataframe for behavioral variables and brain-behavior correlations

